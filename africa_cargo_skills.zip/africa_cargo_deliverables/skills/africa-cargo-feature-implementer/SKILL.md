---
name: africa-cargo-feature-implementer
description: >
  Développe les features complètes d'Africa Cargo : authentification, dashboard,
  enregistrement de colis, suivi, backoffice admin, simulateur de prix, fidélité,
  groupage, livraison à domicile, messagerie. Use when implementing a feature
  from the PRD, building a specific page, adding business logic, or when user
  says "implement [feature]", "build the dashboard", "create the package
  registration", or names any feature from the Africa Cargo PRD. Use AFTER
  architect, supabase-setup, and frontend-builder skills.
---

# Africa Cargo — Feature Implementer

Skill responsable du développement de chaque feature complète d'Africa Cargo.

## When to Use This Skill

Pour implémenter n'importe quelle feature du PRD section 7 :
- Authentification (inscription 2 étapes, connexion, reset password)
- Dashboard client
- Liste des colis avec filtres et onglets
- Enregistrement de colis (wizard 3 étapes)
- Détail d'un colis avec timeline
- Backoffice admin (liste, mise à jour rapide)
- Simulateur de prix public
- Landing page
- Système de fidélité
- Groupage
- Livraison à domicile
- Messagerie
- Avis clients

## CRITICAL: Process for Each Feature

Pour CHAQUE feature, suivre cette séquence :

### Step 1: Read the PRD Section for This Feature

Avant d'écrire une ligne de code, ouvrir `prd/PRD_Africa_Cargo.md` et lire :
- La spécification de l'écran concerné (section 7)
- Les règles métier liées (section 8)
- Le parcours utilisateur (section 4)

### Step 2: Plan the Feature

Identifier :
1. Quelles routes (dans React Router)
2. Quelles requêtes Supabase
3. Quels composants UI (et lesquels existent déjà)
4. Quelles validations (Zod schemas)
5. Quels états (loading, error, empty, success)
6. Quels tests manuels à faire

### Step 3: Create the Feature Folder Structure

```
src/features/[nom-feature]/
├── components/        # Composants spécifiques à cette feature
├── hooks/             # Custom hooks (queries, mutations)
├── lib/               # Helpers, validations Zod
├── pages/             # Pages routes
└── types.ts           # Types spécifiques (si pas dans Supabase)
```

### Step 4: Implement with TanStack Query

Pattern standard pour les requêtes :

```typescript
// src/features/packages/hooks/useColis.ts
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'

export function useColis(clientId: string) {
  return useQuery({
    queryKey: ['colis', clientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('colis')
        .select('*, photos:photos_colis(*), statuts:statuts_colis(*)')
        .eq('client_id', clientId)
        .order('date_enregistrement', { ascending: false })
      if (error) throw error
      return data
    },
  })
}

export function useCreateColis() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: async (colis: NewColis) => {
      const { data, error } = await supabase
        .from('colis')
        .insert(colis)
        .select()
        .single()
      if (error) throw error
      return data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['colis'] })
    },
  })
}
```

### Step 5: Implement Forms with React Hook Form + Zod

Pattern standard :

```typescript
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'

const colisSchema = z.object({
  description: z.string().min(3, 'Minimum 3 caractères'),
  poids_kg: z.number().positive('Doit être positif'),
  axe: z.enum(['Chine', 'Dubai', 'France', 'Nigeria']),
  // ...
})

type ColisForm = z.infer<typeof colisSchema>

export function FormulaireColis() {
  const form = useForm<ColisForm>({
    resolver: zodResolver(colisSchema),
  })

  const createColis = useCreateColis()

  const onSubmit = (data: ColisForm) => {
    createColis.mutate(data, {
      onSuccess: () => navigate('/mes-colis'),
    })
  }

  // ... render
}
```

## Feature-by-Feature Implementation Order

Suivre cet ordre pour respecter les dépendances :

### Sprint 2 — Core Client (Semaines 2-3)

1. **Authentification** (`features/auth/`)
   - Page inscription wizard 2 étapes
   - Page connexion
   - Page reset password
   - Hook useAuth (lit la session Supabase)
   - Routes protégées

2. **Tableau de bord client** (`features/dashboard/`)
   - Page dashboard avec KPIs
   - Cards de KPIs (colis en cours, poids total, fidélité)
   - Liste des 3 colis récents

3. **Enregistrement de colis** (`features/packages/`)
   - Wizard 3 étapes
   - Upload de photos
   - Calcul du prix en temps réel (utiliser règle métier section 8.1)
   - Génération du numéro interne (section 8.3)

4. **Liste des colis** (`features/packages/`)
   - Onglets de filtrage
   - ColisCard (déjà créé dans frontend-builder)
   - Recherche par numéro
   - Filtres par axe, période

5. **Détail d'un colis** (`features/packages/`)
   - Photos en carrousel
   - Timeline des statuts (composant déjà créé)
   - Détails techniques
   - Actions contextuelles selon le statut

6. **Suivi sans compte** (`features/tracking/`)
   - Page publique avec champ de tracking
   - Affichage du statut actuel uniquement
   - Pas d'accès aux infos privées

### Sprint 3 — Backoffice (Semaine 4)

7. **Backoffice — Liste des colis** (`features/admin/`)
   - Vue tableau dense
   - Filtres avancés
   - Action en masse

8. **Backoffice — Mise à jour rapide** (`features/admin/`)
   - 7 boutons pour les 7 statuts
   - Historique des mises à jour
   - Notifications automatiques (préparation pour Phase 2)

9. **Backoffice — Tableau de bord admin** (`features/admin/`)
   - KPIs globaux
   - Tâches du jour
   - Activité récente (logs)

10. **Backoffice — Configuration tarifs** (`features/admin/`)
    - Tableau modifiable
    - Modal d'édition

### Sprint 4 — Fonctionnalités avancées (Semaine 5)

11. **Système de fidélité** (`features/loyalty/`)
    - Affichage du niveau et progression
    - Calcul automatique (règle métier section 8.2)
    - Configuration côté admin

12. **Groupage** (`features/packages/`)
    - Création d'un groupe
    - Ajout/retrait de colis au groupe
    - Suivi du groupe

13. **Livraison à domicile** (`features/packages/`)
    - Bouton sur le détail du colis (statut 6)
    - Formulaire d'adresse
    - Workflow admin (section 8.5)

14. **Avis clients** (`features/feedback/`)
    - Formulaire après livraison
    - Affichage publique sur landing

15. **Messagerie** (`features/messaging/`)
    - Liste des conversations
    - Envoi de messages
    - Notification de nouveau message

### Sprint 5 — Landing et polish (Semaine 6)

16. **Landing page** (`features/landing/`)
    - Hero avec champ de tracking rapide
    - Comment ça marche
    - Simulateur de prix
    - Adresses entrepôts publiques
    - Stats publiques
    - FAQ

17. **Simulateur de prix** (`features/pricing/`)
    - Composant standalone
    - Calcul en temps réel
    - CTA d'inscription

## Validation par feature

À la fin de chaque feature, valider :
- [ ] La feature fonctionne sur Chrome desktop
- [ ] La feature fonctionne sur Chrome mobile (DevTools)
- [ ] La feature fonctionne sur Safari iPhone (test réel ou simulateur)
- [ ] Les états loading et error sont gérés
- [ ] Les permissions RLS sont respectées (un client ne voit que ses données)
- [ ] Les formulaires sont validés (côté client + serveur via RLS)
- [ ] Aucun warning console
- [ ] La feature est documentée brièvement dans le code

## Performance Notes

- Utiliser TanStack Query pour le cache automatique
- Lazy loading des routes avec React.lazy
- Images optimisées (WebP, dimensions adaptées)
- Pas de useEffect inutiles
- Memoization des composants lourds avec React.memo

## Common Patterns

### Toast Notifications
Utiliser `sonner` pour les notifications de succès/erreur :
```tsx
import { toast } from 'sonner'

toast.success('Colis enregistré avec succès')
toast.error('Une erreur est survenue')
```

### Confirmations
Pour les actions destructives, utiliser un AlertDialog shadcn.

### Loading States
- Skeleton pour les listes
- Spinner pour les actions courtes
- Progress bar pour les uploads

## Next Steps

Une fois toutes les features implémentées, utiliser :
- `africa-cargo-qa-tester` pour les tests systématiques avant la livraison
