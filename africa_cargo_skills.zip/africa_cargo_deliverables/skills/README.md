# Africa Cargo — Skills pour Claude Code

Ensemble de 5 skills Claude Code pour développer la plateforme Africa Cargo from scratch.

## Architecture des Skills

Les skills fonctionnent en séquence, chacun avec un domaine de responsabilité précis :

```
1. africa-cargo-architect          → Setup initial du projet (React + Vite + Tailwind)
2. africa-cargo-supabase-setup     → Création de la BDD, tables, RLS
3. africa-cargo-frontend-builder   → Composants UI réutilisables, design system
4. africa-cargo-feature-implementer → Développement de chaque feature
5. africa-cargo-qa-tester          → Tests systématiques avant livraison
```

## Comment installer dans Claude Code

Pour chaque skill :

1. Copier le dossier dans `~/.claude/skills/`
2. Vérifier la présence du fichier `SKILL.md`
3. Redémarrer Claude Code
4. Le skill sera automatiquement détecté

## Comment utiliser

Les skills se déclenchent automatiquement selon le contexte. Tu peux aussi les invoquer explicitement :

```
"Utilise africa-cargo-architect pour setup le projet"
"Utilise africa-cargo-feature-implementer pour développer le dashboard client"
```

## Ordre recommandé d'utilisation

### Sprint 1 (Semaine 1)
- `africa-cargo-architect` (1 fois)
- `africa-cargo-supabase-setup` (1 fois)
- `africa-cargo-frontend-builder` (1 fois)

### Sprints 2-5 (Semaines 2 à 6)
- `africa-cargo-feature-implementer` (à chaque feature)

### Sprint 6 (Semaine 7)
- `africa-cargo-qa-tester` (en boucle jusqu'à ce que tout passe)

## Référence : le PRD

Tous les skills s'appuient sur le PRD complet situé dans `prd/PRD_Africa_Cargo.md`.
Le PRD contient :
- Vision produit et personas
- KPIs à atteindre
- 4 parcours utilisateurs critiques
- Architecture technique complète
- Modèle de données SQL complet (12 tables)
- Spécifications par écran (11 écrans)
- Règles métier (calcul prix, fidélité, etc.)
- Plan de release sprint par sprint

**IMPORTANT** : avant de coder une feature, toujours lire la section correspondante du PRD.

## Stack technique

- React 18 + Vite + TypeScript
- Tailwind CSS + shadcn/ui
- Supabase (PostgreSQL + Auth + Storage)
- TanStack Query + Zustand
- React Hook Form + Zod
- Vercel + Cloudflare

## Contact

Farel — ON AGENCY
Cotonou, Bénin
Avril 2026
