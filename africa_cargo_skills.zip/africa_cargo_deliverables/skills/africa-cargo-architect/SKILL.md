---
name: africa-cargo-architect
description: >
  Initialise et structure le projet Africa Cargo from scratch. Use when starting
  the project, setting up the React + Vite + Tailwind + Supabase stack, creating
  the folder architecture, configuring the toolchain, or when user says "setup
  Africa Cargo project", "init the platform", "scaffold the codebase", or
  mentions starting a new feature in Africa Cargo. Always use this skill before
  any other Africa Cargo skill if no project exists yet.
---

# Africa Cargo — Architect

Skill responsable du setup initial complet du projet Africa Cargo Platform.

## When to Use This Skill

- Création initiale du projet (Sprint 1 du PRD)
- Mise en place de la stack : React 18 + Vite + TypeScript + Tailwind + shadcn/ui
- Configuration Supabase (création projet, env vars, client TypeScript)
- Création de l'architecture de dossiers selon le PRD section 5
- Configuration des outils : ESLint, Prettier, Husky, GitHub Actions
- Setup du PWA (manifest.json, service worker)

## CRITICAL: Read the PRD First

Avant TOUTE action, lire le PRD dans `prd/PRD_Africa_Cargo.md`, particulièrement :
- Section 5 (Architecture technique) pour le découpage du code
- Section 6 (Modèle de données) pour les migrations Supabase
- Section 9 (Sécurité) pour la configuration RLS

## Step 1: Initialize the Project

```bash
# Créer le projet Vite avec React + TypeScript
npm create vite@latest africa-cargo -- --template react-ts
cd africa-cargo

# Installer les dépendances core
npm install @supabase/supabase-js
npm install react-router-dom
npm install @tanstack/react-query
npm install zustand
npm install react-hook-form @hookform/resolvers zod
npm install date-fns
npm install lucide-react
npm install clsx tailwind-merge
```

## Step 2: Setup Tailwind + shadcn/ui

```bash
# Tailwind CSS
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p

# shadcn/ui
npx shadcn-ui@latest init
# Choix recommandés : Default, Slate, CSS variables YES
```

Configurer `tailwind.config.ts` avec les couleurs Africa Cargo :
```ts
colors: {
  primary: {
    DEFAULT: '#1565C0',  // Bleu confiance
    foreground: '#FFFFFF',
  },
  accent: {
    DEFAULT: '#E65100',  // Orange action
    foreground: '#FFFFFF',
  },
}
```

## Step 3: Create Folder Structure

Créer EXACTEMENT cette structure (PRD section 5) :

```
src/
├── components/
│   ├── ui/              # shadcn/ui primitives
│   ├── layout/          # Header, Footer, Sidebar
│   └── shared/          # Composants métier partagés
├── features/
│   ├── auth/
│   ├── packages/
│   ├── tracking/
│   ├── pricing/
│   ├── loyalty/
│   └── admin/
├── pages/
├── lib/
│   ├── supabase.ts
│   ├── utils.ts
│   └── constants.ts
├── hooks/
├── types/
└── App.tsx
```

## Step 4: Configure Supabase Client

Créer `.env.local` avec :
```
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_ANON_KEY=xxx
```

Créer `src/lib/supabase.ts` :
```typescript
import { createClient } from '@supabase/supabase-js'
import type { Database } from '@/types/supabase'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL!
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY!

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey)
```

## Step 5: Create Constants File

Créer `src/lib/constants.ts` avec les constantes du PRD :

```typescript
export const STATUTS_COLIS = [
  { id: 1, libelle: 'Reçu en entrepôt', couleur: 'blue' },
  { id: 2, libelle: 'Chargé', couleur: 'indigo' },
  { id: 3, libelle: 'En transit', couleur: 'purple' },
  { id: 4, libelle: 'Arrivé à Cotonou', couleur: 'pink' },
  { id: 5, libelle: 'En dédouanement', couleur: 'orange' },
  { id: 6, libelle: 'Au magasin Cotonou', couleur: 'yellow' },
  { id: 7, libelle: 'Livré', couleur: 'green' },
] as const

export const AXES = ['Chine', 'Dubai', 'France', 'Nigeria'] as const
export const MODES_ENVOI = ['avion', 'bateau'] as const
export const CATEGORIES = ['Normal', 'Medical', 'Fragile', 'Ordinateur', 'Autre'] as const
export const NIVEAUX_FIDELITE = ['bronze', 'argent', 'or'] as const
```

## Step 6: Setup PWA

Créer `public/manifest.json` :
```json
{
  "name": "Africa Cargo",
  "short_name": "AC",
  "description": "Plateforme de gestion de transit",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#FFFFFF",
  "theme_color": "#1565C0",
  "icons": [
    { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png" }
  ]
}
```

Installer le plugin PWA Vite :
```bash
npm install -D vite-plugin-pwa
```

## Step 7: Initialize Git and Conventions

```bash
git init
git add .
git commit -m "feat: initial setup of Africa Cargo platform"
```

Créer `.gitignore` standard + `.env.local`.

Créer `README.md` avec :
- Description du projet
- Stack technique
- Comment lancer en local
- Comment déployer
- Liens vers le PRD

## Quality Checklist

Avant de passer au skill suivant, vérifier :
- [ ] `npm run dev` lance le projet sans erreur
- [ ] La connexion Supabase est testée (afficher un log de connexion)
- [ ] La structure de dossiers correspond exactement au PRD section 5
- [ ] Tailwind est fonctionnel (test : page avec une couleur primary)
- [ ] shadcn/ui est installé (test : un Button shadcn s'affiche)
- [ ] Le projet est versionné dans GitHub
- [ ] Le manifest PWA est valide

## Next Steps

Une fois ce skill terminé, utiliser :
- `africa-cargo-supabase-setup` pour créer les tables et les policies RLS
- `africa-cargo-feature-implementer` pour développer les features une par une
