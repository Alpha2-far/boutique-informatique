---
name: africa-cargo-frontend-builder
description: >
  Construit les composants UI réutilisables d'Africa Cargo : layout (header,
  sidebar, footer), composants partagés (StatutBadge, ColisCard, FlagIcon,
  PriceDisplay), thème Tailwind, design system. Use when building UI components,
  setting up the design system, creating reusable components, or when user says
  "build the UI", "create the layout", "make the components", "design system",
  or mentions UI/component work for Africa Cargo. Use AFTER supabase setup.
---

# Africa Cargo — Frontend Builder

Skill responsable de la construction du design system et des composants UI réutilisables.

## When to Use This Skill

- Création du layout principal (Header, Sidebar, Footer)
- Composants UI réutilisables (StatutBadge, ColisCard, FlagIcon...)
- Configuration du design system (tokens Tailwind, variants shadcn)
- Composants de formulaire (FormField, FileUpload...)
- États vides et de chargement (EmptyState, Skeleton...)

## Design Principles

Lire le PRD section 4 (Parcours utilisateurs critiques) avant de coder. Le design d'Africa Cargo doit être :

1. **Mobile-first** : 80% des utilisateurs sont sur Android
2. **Rapide** : pas d'animations gratuites, pas de gros assets
3. **Clair** : un client peu technique doit comprendre instantanément
4. **Cohérent** : un seul style, partout
5. **Accessible** : contrastes WCAG AA minimum

## Color Tokens (Design System)

```css
/* Primary - Bleu confiance */
--primary: 211 80% 42%;          /* #1565C0 */
--primary-foreground: 0 0% 100%;

/* Accent - Orange action */
--accent: 22 100% 45%;            /* #E65100 */
--accent-foreground: 0 0% 100%;

/* Statuts colis (7 couleurs) */
--statut-1: 217 91% 60%;  /* Bleu - Reçu */
--statut-2: 239 84% 67%;  /* Indigo - Chargé */
--statut-3: 271 91% 65%;  /* Purple - Transit */
--statut-4: 330 81% 60%;  /* Pink - Cotonou */
--statut-5: 25 95% 53%;   /* Orange - Dédouanement */
--statut-6: 45 93% 47%;   /* Yellow - Magasin */
--statut-7: 142 71% 45%;  /* Green - Livré */
```

## Step 1: Layout Components

### `src/components/layout/Header.tsx`

```tsx
import { Link } from 'react-router-dom'
import { Bell, MessageCircle } from 'lucide-react'
import { useAuth } from '@/features/auth/hooks/useAuth'

export function Header() {
  const { user } = useAuth()
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur">
      <div className="container flex h-14 items-center justify-between">
        <Link to="/" className="font-bold text-primary">Africa Cargo</Link>
        <nav className="flex items-center gap-4">
          {/* WhatsApp Button toujours visible */}
          <a
            href="https://wa.me/22900000000"
            target="_blank"
            className="text-green-600"
          >
            <MessageCircle className="h-5 w-5" />
          </a>
          {user && <Bell className="h-5 w-5" />}
        </nav>
      </div>
    </header>
  )
}
```

### `src/components/layout/Sidebar.tsx`

Sidebar pour le dashboard client avec :
- Avatar + nom + niveau de fidélité
- Menu vertical (Dashboard, Mes colis, Nouveau colis, etc.)
- Bouton WhatsApp en bas

### `src/components/layout/Footer.tsx`

Footer simple avec :
- Liens : Contact, CGU, Mentions légales
- Coordonnées Africa Cargo
- Réseaux sociaux

## Step 2: Shared Business Components

### `StatutBadge.tsx`

Affiche un statut de colis avec la bonne couleur :

```tsx
import { STATUTS_COLIS } from '@/lib/constants'
import { cn } from '@/lib/utils'

interface Props {
  statutId: number
  size?: 'sm' | 'md' | 'lg'
}

export function StatutBadge({ statutId, size = 'md' }: Props) {
  const statut = STATUTS_COLIS.find(s => s.id === statutId)
  if (!statut) return null

  return (
    <span className={cn(
      'inline-flex items-center rounded-full font-medium',
      size === 'sm' && 'px-2 py-0.5 text-xs',
      size === 'md' && 'px-3 py-1 text-sm',
      size === 'lg' && 'px-4 py-1.5 text-base',
      `bg-statut-${statutId}/10 text-statut-${statutId}`
    )}>
      {statut.libelle}
    </span>
  )
}
```

### `ColisCard.tsx`

Card de résumé d'un colis (utilisée dans la liste) :

```tsx
interface Props {
  colis: Colis  // type généré depuis Supabase
}

export function ColisCard({ colis }: Props) {
  return (
    <Link
      to={`/colis/${colis.id}`}
      className="flex gap-4 rounded-lg border bg-white p-4 hover:border-primary"
    >
      <img
        src={colis.photo_principale || '/placeholder-colis.png'}
        className="h-20 w-20 rounded object-cover"
      />
      <div className="flex-1 space-y-1">
        <h3 className="font-medium">{colis.description}</h3>
        <p className="text-sm text-muted-foreground">
          #{colis.numero_interne}
        </p>
        <div className="flex items-center gap-2">
          <FlagIcon pays={colis.axe} />
          <span>→</span>
          <FlagIcon pays="Bénin" />
        </div>
        <StatutBadge statutId={colis.statut} size="sm" />
      </div>
    </Link>
  )
}
```

### `FlagIcon.tsx`

Affiche le drapeau d'un pays :

```tsx
const FLAGS = {
  'Chine': '🇨🇳',
  'Dubai': '🇦🇪',
  'France': '🇫🇷',
  'Nigeria': '🇳🇬',
  'Bénin': '🇧🇯',
}

export function FlagIcon({ pays }: { pays: string }) {
  return <span aria-label={pays}>{FLAGS[pays] || '🌍'}</span>
}
```

### `PriceDisplay.tsx`

Affiche un prix en FCFA correctement formaté :

```tsx
export function PriceDisplay({ amount }: { amount: number }) {
  return (
    <span className="font-semibold tabular-nums">
      {amount.toLocaleString('fr-FR')} FCFA
    </span>
  )
}
```

## Step 3: Form Components

### `FormField.tsx`

Wrapper standard pour les champs de formulaire avec label + erreur :

```tsx
interface Props {
  label: string
  error?: string
  required?: boolean
  children: React.ReactNode
}

export function FormField({ label, error, required, children }: Props) {
  return (
    <div className="space-y-1.5">
      <label className="text-sm font-medium">
        {label}
        {required && <span className="text-red-500"> *</span>}
      </label>
      {children}
      {error && <p className="text-xs text-red-500">{error}</p>}
    </div>
  )
}
```

### `FileUpload.tsx`

Upload de photos vers Supabase Storage avec preview.

## Step 4: Empty States and Loading

### `EmptyState.tsx`

```tsx
interface Props {
  icon: React.ReactNode
  title: string
  description: string
  action?: React.ReactNode
}

export function EmptyState({ icon, title, description, action }: Props) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="mb-4 text-muted-foreground">{icon}</div>
      <h3 className="mb-1 font-semibold">{title}</h3>
      <p className="mb-4 text-sm text-muted-foreground">{description}</p>
      {action}
    </div>
  )
}
```

### `Skeleton.tsx`

Loading states pour cards, listes, détails.

## Step 5: Timeline Component

Pour afficher l'historique des statuts d'un colis (PRD section 7.5) :

```tsx
interface Props {
  statuts: { statut: number; libelle: string; date: string; observations?: string }[]
  statutActuel: number
}

export function StatutsTimeline({ statuts, statutActuel }: Props) {
  return (
    <ol className="relative border-l-2 border-gray-200">
      {STATUTS_COLIS.map((etape) => {
        const evenement = statuts.find(s => s.statut === etape.id)
        const passe = etape.id <= statutActuel
        return (
          <li key={etape.id} className="mb-6 ml-6">
            <span className={cn(
              'absolute -left-3 flex h-6 w-6 items-center justify-center rounded-full',
              passe ? 'bg-primary text-white' : 'bg-gray-200 text-gray-500'
            )}>
              {etape.id}
            </span>
            <h4 className={cn('font-medium', !passe && 'text-muted-foreground')}>
              {etape.libelle}
            </h4>
            {evenement && (
              <>
                <p className="text-xs text-muted-foreground">
                  {format(new Date(evenement.date), 'dd MMM yyyy à HH:mm', { locale: fr })}
                </p>
                {evenement.observations && (
                  <p className="text-sm">{evenement.observations}</p>
                )}
              </>
            )}
          </li>
        )
      })}
    </ol>
  )
}
```

## Quality Checklist

Avant de passer au feature implementer :
- [ ] Tous les composants ci-dessus sont créés et fonctionnels
- [ ] Chaque composant est testé avec différentes props
- [ ] Le design est cohérent (couleurs, espacements, typographie)
- [ ] Les composants fonctionnent en mobile (testé sur 320px width minimum)
- [ ] Les composants sont accessibles (keyboard navigation, aria-labels)
- [ ] Aucun warning console
- [ ] Le storybook est optionnel mais recommandé

## Next Steps

Une fois les composants créés, utiliser :
- `africa-cargo-feature-implementer` pour développer chaque feature complète
