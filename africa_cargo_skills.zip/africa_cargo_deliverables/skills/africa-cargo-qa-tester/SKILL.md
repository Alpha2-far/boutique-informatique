---
name: africa-cargo-qa-tester
description: >
  Teste systématiquement toutes les fonctionnalités d'Africa Cargo avant la
  livraison : tests fonctionnels, parcours utilisateurs, performance, sécurité,
  responsive, accessibilité. Use when ready to test, before deployment, when
  user says "test the app", "check everything works", "QA pass", "validate
  before delivery", or mentions testing/validation for Africa Cargo. Use as the
  LAST skill before deployment.
---

# Africa Cargo — QA Tester

Skill responsable du contrôle qualité complet avant la livraison.

## When to Use This Skill

- Avant la mise en production
- Avant chaque sprint review (premier livrable, livraison finale)
- Quand une feature semble terminée mais doit être validée
- Pour préparer un rapport de tests à envoyer au client/superviseur

## Test Categories

### 1. Tests fonctionnels (les features font ce qu'elles doivent faire)

### 2. Tests de parcours utilisateurs (les workflows fonctionnent de bout en bout)

### 3. Tests de sécurité (RLS, auth, validations)

### 4. Tests de performance (vitesse, optimisation)

### 5. Tests responsive (mobile, tablette, desktop)

### 6. Tests d'accessibilité (clavier, contrastes, screen readers)

---

## Test Plan Complet

### Test Suite 1 : Authentification

**TC-AUTH-001 : Inscription nouvel utilisateur**
- Aller sur `/inscription`
- Étape 1 : remplir tous les champs valides → Continuer
- Étape 2 : remplir avec mot de passe valide → Créer le compte
- Vérifier : redirection vers dashboard, toast de bienvenue, email reçu
- Vérifier en BDD : ligne créée dans `auth.users`, `utilisateurs`, `clients`

**TC-AUTH-002 : Inscription avec email déjà existant**
- Tenter l'inscription avec un email déjà utilisé
- Vérifier : message d'erreur clair, pas de création doublon

**TC-AUTH-003 : Validation des champs obligatoires**
- Soumettre le formulaire avec des champs vides
- Vérifier : messages d'erreur Zod affichés sous chaque champ

**TC-AUTH-004 : Connexion**
- Aller sur `/connexion`
- Saisir email + mot de passe valides → Connexion
- Vérifier : redirection vers dashboard, session persistante

**TC-AUTH-005 : Connexion avec mauvais mot de passe**
- Saisir email valide + mauvais mot de passe
- Vérifier : message d'erreur, pas de session créée

**TC-AUTH-006 : Reset password**
- Cliquer "Mot de passe oublié"
- Saisir email
- Recevoir email avec lien
- Cliquer le lien → définir nouveau mot de passe
- Se connecter avec le nouveau mot de passe

**TC-AUTH-007 : Routes protégées**
- Sans être connecté, tenter d'accéder à `/dashboard`
- Vérifier : redirection vers `/connexion`

### Test Suite 2 : Enregistrement de colis

**TC-COLIS-001 : Wizard complet**
- Aller sur `/nouveau-colis`
- Étape 1 : pays Chine, mode avion, numéro tracking → Suivant
- Étape 2 : photo + description + catégorie + valeur → Suivant
- Étape 3 : poids + dimensions → vérifier prix calculé
- Cliquer "Enregistrer"
- Vérifier : redirection vers détail, colis visible dans liste

**TC-COLIS-002 : Photo obligatoire**
- Tenter de passer l'étape 2 sans photo
- Vérifier : message d'erreur clair

**TC-COLIS-003 : Calcul du prix**
- Tester avec différentes combinaisons (avion vs bateau, fidélité bronze vs or)
- Vérifier que le prix correspond aux règles métier (PRD section 8.1)

**TC-COLIS-004 : Numéro interne unique**
- Créer 5 colis successifs
- Vérifier : numéros AC-2026-0001, 0002, 0003, 0004, 0005

**TC-COLIS-005 : Upload de plusieurs photos**
- Uploader 5 photos (max 5)
- Vérifier : toutes affichées, tentative de 6ème refusée

### Test Suite 3 : Suivi des colis

**TC-SUIVI-001 : Liste avec onglets**
- Avoir des colis dans différents statuts (utiliser l'admin pour les créer)
- Aller sur `/mes-colis`
- Cliquer chaque onglet (Tous, Nouveaux, À expédier, etc.)
- Vérifier : seuls les colis du statut sélectionné s'affichent

**TC-SUIVI-002 : Détail avec timeline**
- Cliquer sur un colis avec plusieurs statuts dans son historique
- Vérifier : timeline affiche tous les statuts dans l'ordre chronologique
- Vérifier : statut actuel mis en évidence
- Vérifier : statuts futurs grisés

**TC-SUIVI-003 : Suivi sans compte**
- Se déconnecter
- Aller sur `/suivi`
- Saisir un numéro de tracking valide
- Vérifier : statut actuel affiché
- Vérifier : pas d'infos privées (description complète, photos, etc.)

### Test Suite 4 : Backoffice

**TC-ADMIN-001 : Connexion admin**
- Se connecter avec un compte admin
- Vérifier : accès à `/admin`
- Vérifier : sidebar admin différente

**TC-ADMIN-002 : Mise à jour rapide d'un statut**
- Aller sur le détail admin d'un colis
- Cliquer sur un statut futur
- Vérifier : statut mis à jour immédiatement
- Vérifier : entrée créée dans `statuts_colis`
- Vérifier : log créé dans `logs`

**TC-ADMIN-003 : Mise à jour en masse**
- Sélectionner 5 colis dans la liste
- Choisir "Mettre à jour vers : Chargé"
- Vérifier : tous les 5 colis mis à jour

**TC-ADMIN-004 : Configuration tarif**
- Modifier un tarif (ex : Normal/Chine/avion)
- Sauvegarder
- Créer un nouveau colis avec ces critères
- Vérifier : nouveau prix appliqué

**TC-ADMIN-005 : Un client ne peut pas accéder à `/admin`**
- Connecté en tant que client, tenter `/admin`
- Vérifier : redirection ou erreur 403

### Test Suite 5 : Sécurité (RLS)

**TC-SEC-001 : Isolation des données client**
- Créer 2 comptes clients (A et B)
- Connecter A, créer un colis
- Se déconnecter, connecter B
- Vérifier : B ne voit pas le colis de A
- Tester aussi via l'API directement (DevTools)

**TC-SEC-002 : Logs d'accès**
- Faire diverses actions admin
- Vérifier dans la table `logs` : chaque action enregistrée

**TC-SEC-003 : Protection brute-force**
- Tenter 6 connexions avec mauvais mot de passe
- Vérifier : à la 6ème, blocage temporaire

**TC-SEC-004 : Validation côté serveur**
- Tenter via DevTools de modifier un colis qui ne nous appartient pas
- Vérifier : Supabase rejette la requête (RLS active)

### Test Suite 6 : Performance

**TC-PERF-001 : Temps de chargement landing**
- Test avec Lighthouse Chrome
- Vérifier : Performance > 90, FCP < 1.5s, LCP < 2.5s

**TC-PERF-002 : Liste des colis avec 50 entrées**
- Créer 50 colis (script SQL)
- Aller sur `/mes-colis`
- Vérifier : chargement < 2s, scroll fluide

**TC-PERF-003 : Upload de photos**
- Uploader une photo de 10 MB
- Vérifier : compression automatique, upload < 5s

**TC-PERF-004 : Mode offline (PWA)**
- Charger l'app
- Couper la connexion
- Naviguer entre les pages déjà visitées
- Vérifier : fonctionne avec données en cache

### Test Suite 7 : Responsive

**TC-RESP-001 : Mobile (320px)**
- Tester toutes les pages sur iPhone SE
- Vérifier : aucun scroll horizontal, tous les boutons cliquables

**TC-RESP-002 : Mobile (375px)**
- Tester sur iPhone 12
- Vérifier : layout cohérent

**TC-RESP-003 : Tablette (768px)**
- Tester sur iPad
- Vérifier : utilisation efficace de l'espace

**TC-RESP-004 : Desktop (1440px)**
- Tester sur écran 1440x900
- Vérifier : pas de zone vide excessive

### Test Suite 8 : Accessibilité

**TC-A11Y-001 : Navigation clavier**
- Naviguer toute l'app avec Tab uniquement
- Vérifier : focus visible partout, ordre logique

**TC-A11Y-002 : Contrastes**
- Lighthouse Accessibility audit
- Vérifier : score > 95

**TC-A11Y-003 : Aria labels**
- Tous les boutons icône ont un aria-label
- Tous les images ont un alt

---

## Bug Report Template

Quand un bug est trouvé, documenter :

```markdown
## Bug : [Titre court]

**Sévérité** : Bloquant / Majeur / Mineur / Cosmétique

**Étapes pour reproduire** :
1. ...
2. ...
3. ...

**Comportement attendu** :
...

**Comportement actuel** :
...

**Environnement** :
- Browser : Chrome 120
- Device : iPhone 12
- URL : ...

**Capture d'écran** : [si applicable]

**Console errors** : [si applicable]
```

## Pre-Deployment Checklist

Avant de mettre en production sur africacargo.bj :

- [ ] Toutes les Test Suites passent à 100%
- [ ] Aucun bug bloquant ou majeur ouvert
- [ ] Tests utilisateurs réels effectués (Africa Cargo + 3 clients tests)
- [ ] Performance Lighthouse > 90 sur Performance, Accessibility, Best Practices, SEO
- [ ] Variables d'environnement configurées sur Vercel
- [ ] Cloudflare configuré (DNS, WAF, SSL)
- [ ] Domaine africacargo.bj pointant vers Vercel
- [ ] Backup BDD configuré
- [ ] Documentation utilisateur livrée
- [ ] Formation équipe Africa Cargo effectuée

## Test Report Template

Pour le client/superviseur, produire un rapport :

```markdown
# Rapport de tests — Africa Cargo Platform V1.0

**Date** : [Date]
**Version testée** : [Numéro]
**Testeur** : [Nom]

## Résumé exécutif
- Total de cas de test : X
- Passés : X (XX%)
- Échoués : X
- Bloqués : X

## Détail par Test Suite
[Tableau avec résultats]

## Bugs identifiés
[Liste des bugs avec sévérité]

## Recommandation
- [ ] Prêt pour production
- [ ] Prêt avec conditions : [liste]
- [ ] Pas prêt, bugs bloquants à corriger

## Captures d'écran
[Annexes]
```

## Performance Notes

Le QA est l'étape qui fait la différence entre un projet "qui marche chez moi" et un produit livrable. Prendre le temps. Ne pas sauter d'étape.
