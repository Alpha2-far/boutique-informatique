---
name: africa-cargo-supabase-setup
description: >
  Crée et configure la base de données Supabase pour Africa Cargo : tables,
  relations, Row Level Security policies, types TypeScript générés, seed data.
  Use when setting up the database, creating migrations, configuring RLS, or
  when user says "setup Supabase", "create the database", "create RLS policies",
  "generate Supabase types", or mentions database work for Africa Cargo. Use
  AFTER africa-cargo-architect skill.
---

# Africa Cargo — Supabase Setup

Skill responsable de toute la configuration de la base de données Supabase.

## When to Use This Skill

- Création des 12 tables du PRD (section 6)
- Configuration des Row Level Security policies
- Génération des types TypeScript
- Création des seed data (données initiales : statuts, tarifs, entrepôts)
- Configuration des Storage buckets pour les photos
- Création des Edge Functions si nécessaire

## CRITICAL: Read the PRD Section 6 First

Toutes les tables, relations, types et politiques sont définies dans le PRD section 6. NE PAS inventer, lire et appliquer.

## Step 1: Create the Supabase Project

Si pas encore fait :
1. Aller sur supabase.com
2. Créer un nouveau projet "africa-cargo"
3. Région : Frankfurt (eu-central-1) — proche du Bénin
4. Mot de passe DB fort généré et stocké en sécurité
5. Récupérer URL et anon key dans Settings → API

## Step 2: Create the Migrations

Créer `supabase/migrations/20260101000000_initial_schema.sql` avec TOUT le SQL du PRD section 6.

Ordre OBLIGATOIRE des tables (à cause des foreign keys) :
1. utilisateurs
2. clients
3. entrepots
4. tarifs
5. groupage
6. config_fidelite
7. colis (référence client_id, entrepot_id, groupage_id)
8. photos_colis
9. statuts_colis
10. paiements
11. messages
12. avis
13. logs

## Step 3: Apply RLS Policies

Pour CHAQUE table, créer les policies appropriées. Pattern de base :

```sql
-- Activer RLS
ALTER TABLE public.[table_name] ENABLE ROW LEVEL SECURITY;

-- Policy SELECT : client voit ses données, admin voit tout
CREATE POLICY "[table]_select" ON public.[table_name]
  FOR SELECT USING (
    -- Client : ses propres données
    [condition_propriete]
    OR
    -- Admin : tout
    EXISTS (
      SELECT 1 FROM public.utilisateurs
      WHERE id = auth.uid() AND role IN ('admin', 'agent')
    )
  );
```

### Policies spécifiques par table

**utilisateurs** : un utilisateur voit son propre profil, admins voient tout
**clients** : un client voit son profil, admins voient tout
**colis** : un client voit ses colis (via clients.utilisateur_id = auth.uid()), admins voient tout
**statuts_colis** : visible si le colis est visible
**photos_colis** : visible si le colis est visible
**entrepots** : LECTURE PUBLIQUE (pas de RLS sur SELECT, ou policy permissive)
**tarifs** : LECTURE PUBLIQUE
**logs** : ADMIN UNIQUEMENT (pas de SELECT pour les clients)

## Step 4: Create Storage Buckets

Dans Supabase Dashboard → Storage :
- Bucket `colis-photos` : public read, authenticated write
- Bucket `avatars` (futur) : public read, authenticated write par utilisateur

## Step 5: Generate TypeScript Types

```bash
# Installer la CLI Supabase
npm install -g supabase

# Login
supabase login

# Link au projet
supabase link --project-ref [project-ref]

# Générer les types
supabase gen types typescript --linked > src/types/supabase.ts
```

## Step 6: Seed Data

Créer `supabase/seed.sql` avec :

```sql
-- Adresses des entrepôts (à confirmer avec Africa Cargo)
INSERT INTO public.entrepots (pays, ville, adresse_complete, ordre_affichage) VALUES
  ('Chine', 'Guangzhou', '[Adresse Africa Cargo Chine - à fournir]', 1),
  ('Dubai', 'Dubai', '[Adresse Africa Cargo Dubai - à fournir]', 2),
  ('France', 'Paris', '[Adresse Africa Cargo France - à fournir]', 3),
  ('Nigeria', 'Lagos', '[Adresse Africa Cargo Nigeria - à fournir]', 4);

-- Tarifs initiaux (placeholders, à confirmer)
INSERT INTO public.tarifs (categorie, axe, mode_envoi, prix_par_kg) VALUES
  ('Normal', 'Chine', 'avion', 5500),
  ('Normal', 'Chine', 'bateau', 2500),
  ('Normal', 'Dubai', 'avion', 6000),
  ('Normal', 'Dubai', 'bateau', 3000);
  -- Compléter selon les tarifs fournis par Africa Cargo

-- Configuration fidélité par défaut
INSERT INTO public.config_fidelite (niveau, seuil_kg_cumule, taux_reduction) VALUES
  ('bronze', 0, 0),
  ('argent', 100, 5),
  ('or', 500, 10);

-- Compte admin de test (à créer manuellement via Supabase Auth)
-- Puis lier ici :
-- INSERT INTO public.utilisateurs (id, nom, prenom, email, telephone, role)
-- VALUES ('[uuid_de_l_admin]', 'Adolphe', 'DG', 'admin@africacargo.bj', '+22900000000', 'admin');
```

## Step 7: Create Helper Functions

Créer `src/lib/supabase-queries.ts` avec les requêtes communes :

```typescript
import { supabase } from './supabase'

export async function getColisDuClient(clientId: string) {
  return supabase
    .from('colis')
    .select(`
      *,
      photos:photos_colis(url_photo, ordre),
      statuts:statuts_colis(statut, libelle, date_mise_a_jour),
      entrepot:entrepots(pays, ville)
    `)
    .eq('client_id', clientId)
    .order('date_enregistrement', { ascending: false })
}

export async function getColisParTracking(numeroTracking: string) {
  return supabase
    .from('colis')
    .select('*, statuts:statuts_colis(*)')
    .or(`numero_tracking_externe.eq.${numeroTracking},numero_interne.eq.${numeroTracking}`)
    .single()
}

// Ajouter d'autres requêtes communes
```

## Quality Checklist

Avant de passer au skill suivant :
- [ ] Toutes les tables sont créées (vérifier dans Supabase Dashboard → Table Editor)
- [ ] RLS est activé sur TOUTES les tables (badge vert dans le dashboard)
- [ ] Les policies sont testées (un utilisateur test ne voit pas les données d'un autre)
- [ ] Les types TypeScript sont générés et importables
- [ ] Le seed data est appliqué
- [ ] Le bucket `colis-photos` existe
- [ ] Une requête simple fonctionne depuis l'app React

## Troubleshooting

### Erreur : "permission denied for table X"
Cause : RLS activé mais aucune policy ne permet l'accès.
Solution : Vérifier les policies pour cette table, ou créer une policy permissive temporaire.

### Erreur : "relation does not exist"
Cause : Migration pas encore appliquée.
Solution : Vérifier l'ordre des migrations, relancer `supabase db push`.

### Types TypeScript pas à jour
Solution : Relancer `supabase gen types typescript --linked > src/types/supabase.ts`

## Next Steps

Une fois Supabase configuré, utiliser :
- `africa-cargo-frontend-builder` pour créer les composants UI réutilisables
- `africa-cargo-feature-implementer` pour développer chaque feature
