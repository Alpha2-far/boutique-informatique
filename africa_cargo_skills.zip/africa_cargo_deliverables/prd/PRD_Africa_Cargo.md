# PRD — Africa Cargo Platform

**Product Requirements Document**
Version 1.0 — Avril 2026
Préparé par : ON AGENCY (Farel)
Stack : React + Vite + Tailwind + Supabase + Vercel + Cloudflare

---

## Table des matières

1. [Vision Produit](#1-vision-produit)
2. [Personas et utilisateurs cibles](#2-personas-et-utilisateurs-cibles)
3. [Objectifs et KPIs](#3-objectifs-et-kpis)
4. [Parcours utilisateurs critiques](#4-parcours-utilisateurs-critiques)
5. [Architecture technique](#5-architecture-technique)
6. [Modèle de données complet](#6-modele-de-donnees-complet)
7. [Spécifications par écran](#7-specifications-par-ecran)
8. [Règles métier](#8-regles-metier)
9. [Sécurité et conformité](#9-securite-et-conformite)
10. [Plan de release](#10-plan-de-release)

---

## 1. Vision Produit

### Le problème
Africa Cargo est une société de transit qui importe des marchandises depuis la Chine, Dubaï, la France et le Nigéria vers Cotonou. Aujourd'hui :
- L'ancien site a été piraté et est inaccessible
- La gestion des colis est manuelle (WhatsApp, appels, fichiers Excel)
- Les clients appellent constamment pour savoir où en est leur colis
- Aucune visibilité sur l'historique d'un client
- Les tarifs sont communiqués oralement, source d'erreurs et de litiges

### La solution
Une Application Web Progressive (PWA) qui permet :
- Aux clients d'enregistrer leurs colis et de suivre leur statut en autonomie
- À l'équipe Africa Cargo de mettre à jour les statuts depuis un backoffice simple
- Aux visiteurs de simuler un prix sans créer de compte
- À tous d'accéder via un navigateur web (pas besoin de Play Store ou App Store)

### Promesse de valeur
> "Importez en autonomie. Suivez en temps réel. Sans appeler personne."

### Vision à 12 mois
Devenir la plateforme de référence du transit au Bénin sur les axes Chine, Dubaï, France et Nigéria. Étendre ensuite vers le paiement en ligne (Phase 2), la livraison à domicile gérée nativement, et l'expansion vers d'autres pays d'Afrique de l'Ouest.

---

## 2. Personas et utilisateurs cibles

### Persona 1 : Adèle, la commerçante (Client principal)
- **Âge** : 35 ans
- **Profession** : Commerçante au marché Dantokpa
- **Achète** : Vêtements, chaussures, accessoires sur AliExpress et 1688
- **Volume** : 8 à 15 colis par mois
- **Tech** : Android Tecno, WhatsApp tous les jours, achat en ligne via Wave/MTN
- **Frustrations actuelles** : Perd du temps à appeler Africa Cargo pour savoir où sont ses colis. A déjà perdu un colis car personne ne le suivait correctement.
- **Ce qu'elle veut** : Voir tous ses colis d'un coup d'œil, savoir lesquels sont arrivés.

### Persona 2 : Marc, le particulier occasionnel
- **Âge** : 28 ans
- **Profession** : Cadre dans une PME
- **Achète** : Électronique, gadgets, parfois quelques vêtements
- **Volume** : 1 à 3 colis par mois
- **Tech** : iPhone, navigation web fluide, paie par carte ou Mobile Money
- **Ce qu'il veut** : Une expérience moderne, comme Amazon. S'il doit appeler, c'est qu'il y a un problème.

### Persona 3 : Adolphe, le DG d'Africa Cargo
- **Profil** : Entrepreneur béninois, gère son équipe, sait ce qu'il veut
- **Frustrations** : A perdu son ancien site, ne veut plus dépendre d'un développeur unique
- **Ce qu'il veut** : Voir d'un coup d'œil combien de colis sont en cours, qui doit quoi, et que tout marche sans qu'il intervienne techniquement

### Persona 4 : Jean, l'agent Africa Cargo
- **Profil** : Agent au magasin de Cotonou, 30 ans, peu technique
- **Mission** : Met à jour les statuts des colis quand ils arrivent, accueille les clients qui viennent récupérer
- **Ce qu'il veut** : Pouvoir mettre à jour 30 colis en 5 minutes, sans se tromper, sans avoir besoin d'aide

---

## 3. Objectifs et KPIs

### Objectifs business (Africa Cargo)
| Objectif | Métrique | Cible 3 mois | Cible 12 mois |
|----------|----------|--------------|---------------|
| Réduire les appels au support | Nombre d'appels/semaine | -40% | -70% |
| Augmenter le volume de colis | Colis traités/mois | +20% | +60% |
| Fidéliser les clients | Clients actifs/mois | 150 | 400 |
| Réduire les litiges | Litiges sur statut | -50% | -80% |

### Objectifs produit (ON AGENCY)
| Objectif | Métrique | Cible |
|----------|----------|-------|
| Activation | % de nouveaux inscrits qui enregistrent un colis dans les 7 jours | 60% |
| Rétention | % de clients qui reviennent après 30 jours | 70% |
| Engagement | Visites par client par mois | 8 |
| Performance | Temps de chargement page d'accueil | < 2s |
| Disponibilité | Uptime mensuel | 99.9% |

### Le moment d'activation (le plus critique)
> Un client est "activé" quand il a enregistré son premier colis ET que ce colis a au moins atteint le statut "Reçu en entrepôt".

C'est le moment où le client comprend la valeur de la plateforme. Tout le design produit doit converger vers ce moment.

---

## 4. Parcours utilisateurs critiques

### Parcours 1 : Premier achat → Premier colis enregistré (CRITIQUE)

```
1. Le client achète sur AliExpress
2. AliExpress demande une adresse de livraison
3. Le client doit aller chercher l'adresse de l'entrepôt Africa Cargo en Chine
   ↓ Point de friction MAJEUR
4. Le client copie l'adresse
5. Il valide sa commande et reçoit un numéro de tracking
6. Plus tard, il enregistre le colis sur Africa Cargo Platform
   ↓ Si pas inscrit : friction d'inscription
7. Il attend que le colis arrive
```

**Solutions UX pour réduire la friction :**
- L'adresse des entrepôts doit être accessible SANS connexion (sur la landing page)
- Bouton "Copier" directement à côté de chaque adresse
- Un guide visuel "Comment commander en Chine" sur la landing page
- L'inscription ne doit pas demander plus de 5 champs essentiels en première étape

### Parcours 2 : Suivi quotidien d'un colis en cours

```
1. Le client se connecte (idéalement déjà connecté grâce à PWA)
2. Il voit son tableau de bord avec les colis en cours
3. Il clique sur un colis pour voir l'historique des statuts
4. Il voit la date de mise à jour
5. Il ferme l'app, satisfait
```

**Mesure du succès** : 0 appel au support pour ce parcours.

### Parcours 3 : Mise à jour de statuts par l'équipe Africa Cargo

```
1. Jean arrive au magasin le matin
2. 15 colis sont arrivés du conteneur
3. Il scanne ou tape les numéros de tracking un par un
4. Pour chaque colis : Il clique sur "Reçu" → confirme → passe au suivant
5. Total : 15 colis mis à jour en moins de 3 minutes
```

**Contrainte forte** : Cette opération doit être ULTRA rapide. Pas de menus, pas de confirmation lourde. Une recherche par numéro, un bouton, terminé.

### Parcours 4 : Visiteur qui découvre Africa Cargo

```
1. Le visiteur arrive sur la landing page
2. Il voit immédiatement : "Importez de Chine, Dubaï, France, Nigéria vers Cotonou"
3. Il teste le simulateur de prix sans s'inscrire
4. Il consulte les adresses des entrepôts
5. Il clique sur "S'inscrire" parce qu'il est convaincu
```

**Mesure du succès** : Taux de conversion visiteur → inscription > 5%.

---

## 5. Architecture technique

### Stack technique définitif
| Couche | Technologie | Justification |
|--------|-------------|---------------|
| Front-end | React 18 + Vite + TypeScript | Performance, écosystème mature |
| Styling | Tailwind CSS + shadcn/ui | Rapidité de dev, design cohérent |
| State management | TanStack Query + Zustand | Cache serveur + état UI léger |
| Routing | React Router v6 | Standard de fait |
| Forms | React Hook Form + Zod | Validation typée robuste |
| Base de données | Supabase (PostgreSQL) | Auth, RLS, realtime intégrés |
| Auth | Supabase Auth | Magic link, OTP, password |
| Storage | Supabase Storage | Photos colis |
| Hébergement | Vercel | Déploiement automatique GitHub |
| CDN/Sécurité | Cloudflare (proxy) | DDoS, WAF, cache |
| Monitoring | Vercel Analytics + Sentry (gratuit) | Performance + erreurs |
| Domaine | africacargo.bj (à acheter) | Confiance locale |

### Architecture en couches

```
┌─────────────────────────────────────────────┐
│         CLOUDFLARE (CDN + WAF)              │
│  Protection DDoS, cache, certificat SSL     │
└─────────────────┬───────────────────────────┘
                  │
┌─────────────────▼───────────────────────────┐
│              VERCEL (Hosting)                │
│  Application React (SPA + PWA)              │
│  Service Worker pour mode hors-ligne        │
└─────────────────┬───────────────────────────┘
                  │
┌─────────────────▼───────────────────────────┐
│            SUPABASE (Backend)                │
│  ┌──────────────────────────────────────┐  │
│  │  Auth (gestion sessions et rôles)    │  │
│  ├──────────────────────────────────────┤  │
│  │  PostgreSQL + Row Level Security     │  │
│  ├──────────────────────────────────────┤  │
│  │  Storage (photos colis)              │  │
│  ├──────────────────────────────────────┤  │
│  │  Edge Functions (logique métier)     │  │
│  └──────────────────────────────────────┘  │
└──────────────────────────────────────────────┘
```

### Découpage du code (mono-repo)

```
africa-cargo/
├── src/
│   ├── components/          # Composants UI réutilisables
│   │   ├── ui/              # shadcn/ui primitives
│   │   ├── layout/          # Header, Footer, Sidebar
│   │   └── shared/          # Composants métier partagés
│   ├── features/            # Features par domaine
│   │   ├── auth/            # Inscription, connexion
│   │   ├── packages/        # Gestion des colis
│   │   ├── tracking/        # Suivi des statuts
│   │   ├── pricing/         # Simulateur, tarifs
│   │   ├── loyalty/         # Système de fidélité
│   │   └── admin/           # Backoffice
│   ├── pages/               # Routes principales
│   ├── lib/                 # Utilitaires
│   │   ├── supabase.ts      # Client Supabase
│   │   ├── utils.ts         # Helpers
│   │   └── constants.ts     # Constantes (statuts, axes...)
│   ├── hooks/               # Custom hooks
│   ├── types/               # Types TypeScript
│   └── App.tsx
├── public/
│   ├── manifest.json        # PWA manifest
│   └── service-worker.js    # PWA service worker
├── supabase/
│   ├── migrations/          # Migrations SQL versionnées
│   └── seed.sql             # Données de test
└── package.json
```

---

## 6. Modèle de données complet

### Schéma SQL (à créer dans Supabase)

```sql
-- ═══════════════════════════════════════════════════════════════
-- TABLE : utilisateurs (extension de auth.users)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.utilisateurs (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nom TEXT NOT NULL,
  prenom TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  telephone TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'client' CHECK (role IN ('client', 'admin', 'agent')),
  date_inscription TIMESTAMPTZ DEFAULT NOW(),
  niveau_fidelite TEXT DEFAULT 'bronze' CHECK (niveau_fidelite IN ('bronze', 'argent', 'or')),
  code_parrainage TEXT UNIQUE,
  code_parrain_utilise TEXT REFERENCES public.utilisateurs(code_parrainage),
  actif BOOLEAN DEFAULT TRUE
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : clients (profil étendu)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  utilisateur_id UUID NOT NULL REFERENCES public.utilisateurs(id) ON DELETE CASCADE,
  pays_residence TEXT NOT NULL DEFAULT 'Bénin',
  ville TEXT NOT NULL,
  adresse_complete TEXT,
  nom_entreprise TEXT,
  contact_alternatif TEXT,
  date_creation TIMESTAMPTZ DEFAULT NOW()
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : entrepots (entrepôts Africa Cargo à l'étranger)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.entrepots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pays TEXT NOT NULL CHECK (pays IN ('Chine', 'Dubai', 'France', 'Nigeria')),
  ville TEXT NOT NULL,
  adresse_complete TEXT NOT NULL,
  contact TEXT,
  responsable TEXT,
  actif BOOLEAN DEFAULT TRUE,
  ordre_affichage INT DEFAULT 0
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : tarifs (grille tarifaire)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.tarifs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  categorie TEXT NOT NULL CHECK (categorie IN ('Normal', 'Medical', 'Fragile', 'Ordinateur', 'Autre')),
  axe TEXT NOT NULL CHECK (axe IN ('Chine', 'Dubai', 'France', 'Nigeria')),
  mode_envoi TEXT NOT NULL CHECK (mode_envoi IN ('avion', 'bateau')),
  prix_par_kg INT,
  prix_par_m3 INT,
  date_mise_a_jour TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(categorie, axe, mode_envoi)
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : colis (table centrale)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.colis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES public.clients(id),
  entrepot_id UUID REFERENCES public.entrepots(id),
  numero_interne TEXT UNIQUE NOT NULL,
  numero_tracking_externe TEXT,
  description TEXT NOT NULL,
  nature TEXT CHECK (nature IN ('Normal', 'Medical', 'Fragile', 'Ordinateur', 'Autre')),
  poids_kg DECIMAL(10,2),
  longueur_cm DECIMAL(10,2),
  largeur_cm DECIMAL(10,2),
  hauteur_cm DECIMAL(10,2),
  valeur_declaree_fcfa INT,
  mode_envoi TEXT CHECK (mode_envoi IN ('avion', 'bateau')),
  axe TEXT CHECK (axe IN ('Chine', 'Dubai', 'France', 'Nigeria')),
  statut INT DEFAULT 0 CHECK (statut BETWEEN 0 AND 7),
  prix_calcule_fcfa INT,
  groupage_id UUID,
  date_enregistrement TIMESTAMPTZ DEFAULT NOW(),
  date_arrivee_estimee DATE,
  livraison_domicile BOOLEAN DEFAULT FALSE
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : photos_colis
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.photos_colis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  colis_id UUID NOT NULL REFERENCES public.colis(id) ON DELETE CASCADE,
  url_photo TEXT NOT NULL,
  ordre INT DEFAULT 0,
  date_upload TIMESTAMPTZ DEFAULT NOW()
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : statuts_colis (historique des statuts)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.statuts_colis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  colis_id UUID NOT NULL REFERENCES public.colis(id) ON DELETE CASCADE,
  statut INT NOT NULL CHECK (statut BETWEEN 1 AND 7),
  libelle TEXT NOT NULL,
  observations TEXT,
  date_mise_a_jour TIMESTAMPTZ DEFAULT NOW(),
  admin_id UUID REFERENCES public.utilisateurs(id),
  notification_envoyee BOOLEAN DEFAULT FALSE
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : groupage
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.groupage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES public.clients(id),
  nom_groupe TEXT,
  axe TEXT CHECK (axe IN ('Chine', 'Dubai', 'France', 'Nigeria')),
  date_creation TIMESTAMPTZ DEFAULT NOW(),
  statut_groupe TEXT DEFAULT 'en_cours',
  observations TEXT
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : fidelite (configuration par Africa Cargo)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.config_fidelite (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  niveau TEXT UNIQUE CHECK (niveau IN ('bronze', 'argent', 'or')),
  seuil_kg_cumule INT,
  seuil_montant_cumule_fcfa INT,
  seuil_nombre_colis INT,
  taux_reduction DECIMAL(5,2)
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : paiements (structure inactive en V1)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.paiements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  colis_id UUID REFERENCES public.colis(id),
  client_id UUID REFERENCES public.clients(id),
  mode_paiement TEXT CHECK (mode_paiement IN ('cash', 'mtn_momo', 'moov_money', 'fedapay', 'virement')),
  montant_fcfa INT,
  date_paiement TIMESTAMPTZ,
  statut_paiement TEXT DEFAULT 'en_attente',
  reference_transaction TEXT,
  notes TEXT
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : messages (messagerie client - admin)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  expediteur_id UUID NOT NULL REFERENCES public.utilisateurs(id),
  destinataire_id UUID REFERENCES public.utilisateurs(id),
  sujet TEXT,
  contenu TEXT NOT NULL,
  colis_id UUID REFERENCES public.colis(id),
  date_envoi TIMESTAMPTZ DEFAULT NOW(),
  lu BOOLEAN DEFAULT FALSE
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : avis (avis et suggestions clients)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.avis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES public.clients(id),
  note INT CHECK (note BETWEEN 1 AND 5),
  commentaire TEXT,
  date_creation TIMESTAMPTZ DEFAULT NOW(),
  publie BOOLEAN DEFAULT FALSE
);

-- ═══════════════════════════════════════════════════════════════
-- TABLE : logs (journal des actions)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE public.logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  utilisateur_id UUID REFERENCES public.utilisateurs(id),
  action TEXT NOT NULL,
  description TEXT,
  ip_address TEXT,
  user_agent TEXT,
  date_action TIMESTAMPTZ DEFAULT NOW()
);
```

### Politiques de sécurité (Row Level Security)

```sql
-- Activer RLS sur toutes les tables
ALTER TABLE public.utilisateurs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.colis ENABLE ROW LEVEL SECURITY;
-- ... toutes les autres

-- Politique : un client ne voit QUE ses propres colis
CREATE POLICY "client_voit_ses_colis" ON public.colis
  FOR SELECT
  USING (
    client_id IN (
      SELECT id FROM public.clients WHERE utilisateur_id = auth.uid()
    )
  );

-- Politique : un admin voit tout
CREATE POLICY "admin_voit_tout" ON public.colis
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.utilisateurs
      WHERE id = auth.uid() AND role IN ('admin', 'agent')
    )
  );
```

---

## 7. Spécifications par écran

### 7.1 Landing Page (`/`)

**Objectif** : Convertir le visiteur en utilisateur inscrit.

**Sections (de haut en bas) :**

1. **Hero** (above the fold)
   - Titre : "Importez depuis la Chine, Dubaï, France et Nigéria. Suivez en temps réel."
   - Sous-titre : "La plateforme officielle d'Africa Cargo pour gérer vos colis en autonomie"
   - 2 CTA : "Suivre un colis" (primaire) + "S'inscrire gratuitement" (secondaire)
   - Visuel : illustration d'un colis ou d'une carte du monde avec les 4 axes
   - Champ rapide : "Entrez votre numéro de tracking" → résultat instantané

2. **Comment ça marche** (3 étapes)
   - Étape 1 : Inscrivez-vous gratuitement
   - Étape 2 : Achetez à l'étranger avec notre adresse
   - Étape 3 : Suivez votre colis jusqu'à Cotonou

3. **Simulateur de prix** (sans connexion)
   - Champs : Pays d'origine, Mode d'envoi, Poids, Dimensions, Catégorie
   - Résultat affiché en temps réel
   - CTA : "Créer un compte pour enregistrer ce colis"

4. **Adresses des entrepôts**
   - 4 cartes (Chine, Dubaï, France, Nigéria)
   - Chaque carte : adresse complète + bouton "Copier"
   - Note : "Utilisez ces adresses lors de vos achats en ligne"

5. **Statistiques publiques**
   - "X colis traités ce mois"
   - "X clients actifs"
   - "X jours de délai moyen"
   - Mises à jour automatiquement depuis la base

6. **Témoignages clients** (si disponibles)
   - 3 avis 5 étoiles publics
   - Photo + nom + extrait

7. **FAQ** (accordéon)
   - "Comment fonctionne Africa Cargo ?"
   - "Quels sont les délais ?"
   - "Comment payer ?"
   - "Que faire si mon colis est perdu ?"

8. **Footer**
   - Liens : Contact, Mentions légales, CGU
   - Réseaux sociaux
   - WhatsApp Business cliquable

**Métriques à tracker** : taux de scroll, clics sur CTA, utilisations du simulateur, copies d'adresse.

### 7.2 Inscription (`/inscription`)

**Décomposée en 2 étapes (selon Intercargo qu'on étudie) :**

**Étape 1 : Identité**
- Pays de résidence (select avec drapeaux)
- Ville
- Adresse email
- Prénom
- Nom
- CTA : "Continuer"

**Étape 2 : Compte**
- Numéro de téléphone (avec indicatif pays par défaut +229)
- Nom de l'entreprise (optionnel)
- Code de parrainage (optionnel)
- Mot de passe
- Confirmation mot de passe
- Case "J'accepte les CGU"
- CTA : "Créer mon compte"

**Validations :**
- Email valide et unique
- Téléphone valide selon le pays
- Mot de passe 8+ caractères avec 1 majuscule, 1 chiffre

**Après inscription :**
- Redirection vers le tableau de bord avec un toast "Bienvenue [Prénom]"
- Email de bienvenue envoyé automatiquement
- Premier écran : guide en 3 étapes "Comment enregistrer votre premier colis"

### 7.3 Tableau de bord client (`/dashboard`)

**Layout :** Sidebar gauche + contenu principal

**Sidebar (sticky) :**
- Logo Africa Cargo
- Avatar + nom du client
- Niveau de fidélité (badge coloré)
- Menu :
  - Tableau de bord
  - Mes colis
  - Nouveau colis
  - Adresses entrepôts
  - Tarifs
  - Messagerie
  - Mon profil
- Bouton WhatsApp (en bas)

**Contenu principal :**

1. **Bandeau de bienvenue**
   - "Bonjour [Prénom], voici un résumé de vos colis"

2. **KPIs du client** (4 cartes)
   - Colis en cours : X
   - Colis livrés ce mois : X
   - Poids total importé : X kg
   - Niveau de fidélité actuel + progression vers le niveau suivant

3. **Colis récents** (3 derniers)
   - Mini-card par colis avec : photo, description courte, statut visuel
   - Lien "Voir tous mes colis"

4. **Notifications** (si pertinentes)
   - "Votre colis [nom] est arrivé au magasin"
   - "Une mise à jour de tarif a été effectuée"

5. **Actions rapides**
   - Bouton "Enregistrer un nouveau colis"
   - Bouton "Voir les adresses des entrepôts"

### 7.4 Liste des colis (`/mes-colis`)

**Onglets en haut** : Tous / Nouveaux / À expédier / En transit / À retirer / Retirés

**Liste de cards (mobile-first) :**

Chaque card affiche :
- Photo principale du colis (à gauche)
- Description (max 2 lignes)
- Numéro de tracking
- Pays d'origine (drapeau) → Bénin (drapeau)
- Statut actuel (badge coloré)
- Date d'enregistrement
- Prix (si calculé)
- Tap → ouvre le détail

**Filtres** (en haut, dépliable) :
- Par axe
- Par mode d'envoi
- Par période
- Recherche par numéro de tracking

### 7.5 Détail d'un colis (`/colis/:id`)

**Sections :**

1. **Header**
   - Description
   - Numéro interne et numéro tracking
   - Statut actuel (gros badge)

2. **Photos** (carrousel)

3. **Timeline des statuts** (visuel chronologique)
   - Chaque étape : icône + libellé + date + observations
   - Étapes futures grisées

4. **Détails techniques**
   - Poids, dimensions, catégorie, mode d'envoi
   - Valeur déclarée
   - Prix calculé

5. **Actions** (selon statut)
   - Si "À retirer" : bouton "Demander livraison à domicile"
   - Toujours : bouton "Contacter le service"
   - Si "Livré" : bouton "Laisser un avis"

### 7.6 Enregistrement de colis (`/nouveau-colis`)

**Formulaire en 3 étapes (wizard) :**

**Étape 1 : Origine et expédition**
- Pays d'origine (4 choix avec drapeaux)
- Mode d'envoi (avion / bateau avec icônes)
- Numéro de tracking du transporteur
- Date d'envoi prévue

**Étape 2 : Description**
- Photo principale (obligatoire)
- Photos supplémentaires (max 4)
- Description (textarea)
- Catégorie (select)
- Valeur déclarée (FCFA)

**Étape 3 : Dimensions et poids**
- Poids estimé (kg)
- Longueur, largeur, hauteur (cm)
- Aperçu du prix calculé en temps réel
- CTA : "Enregistrer ce colis"

**Après validation :**
- Toast de succès
- Redirection vers le détail du colis nouvellement créé
- Email de confirmation envoyé

### 7.7 Backoffice — Liste des colis (`/admin/colis`)

**Vue tableau dense** (pas de cards, l'agent gère 50+ colis par jour) :

| # | Numéro | Client | Description | Statut | Axe | Date | Actions |
|---|--------|--------|-------------|--------|-----|------|---------|

**Filtres en haut :**
- Recherche par numéro
- Filtre par statut, axe, période, client
- Tri par date, statut

**Action principale par ligne :** dropdown "Changer le statut" avec les 7 options.

**Action en masse :** sélection multiple → "Mettre à jour le statut sélectionné"

### 7.8 Backoffice — Mise à jour rapide d'un colis (`/admin/colis/:id`)

**Vue épurée pour les agents :**

- Photo et description du colis
- Statut actuel (visuel)
- 7 boutons (un par statut) → clic = mise à jour immédiate avec confirmation

```
┌──────────────────────────────────────────┐
│  Colis #AC-2026-0142                    │
│  [Photo]  Veste cuir noire — Adèle       │
│  Statut : ✓ Reçu en entrepôt            │
│                                          │
│  Mettre à jour vers :                    │
│  [✓ Reçu] [Chargé] [Transit] [Cotonou]  │
│  [Dédouanement] [Magasin] [Livré]       │
│                                          │
│  [Notes optionnelles : ___________]     │
└──────────────────────────────────────────┘
```

### 7.9 Backoffice — Tableau de bord admin (`/admin`)

**KPIs globaux :**
- Colis en cours par statut (donut chart)
- Colis traités cette semaine
- Clients actifs
- Volume par axe

**Tâches du jour :**
- "23 colis arrivés au magasin attendent confirmation"
- "5 nouveaux clients inscrits aujourd'hui"
- "3 messages non lus"

**Activité récente :**
- Stream des dernières actions (qui a fait quoi)

### 7.10 Backoffice — Configuration tarifs (`/admin/tarifs`)

**Tableau modifiable :**

| Catégorie | Axe | Mode | Prix/kg | Prix/m³ | Action |
|-----------|-----|------|---------|---------|--------|
| Normal | Chine | Avion | 5500 | - | Modifier |

Modal de modification avec champs et bouton "Enregistrer".

### 7.11 Backoffice — Configuration fidélité (`/admin/fidelite`)

**3 cards** (Bronze, Argent, Or) avec champs modifiables :
- Seuil de déclenchement (kg cumulé OU montant cumulé)
- Taux de réduction (%)
- Bouton "Enregistrer"

---

## 8. Règles métier

### 8.1 Calcul du prix d'un colis

```
Si mode_envoi = 'avion':
    prix_base = poids_kg * tarif.prix_par_kg
Si mode_envoi = 'bateau':
    volume_m3 = (longueur * largeur * hauteur) / 1_000_000
    prix_base = max(volume_m3 * tarif.prix_par_m3, poids_kg * 0.4 * tarif.prix_par_m3)

Si client.niveau_fidelite = 'argent':
    prix_final = prix_base * (1 - tarif_argent / 100)
Sinon si client.niveau_fidelite = 'or':
    prix_final = prix_base * (1 - tarif_or / 100)

Retourner arrondi(prix_final, 100)  // Arrondi à la centaine
```

### 8.2 Évolution du niveau de fidélité

Recalculé à chaque livraison de colis :
```
total_kg_cumule = SUM(poids_kg) WHERE statut = 7
total_montant_cumule = SUM(prix_calcule_fcfa) WHERE statut = 7

Si total_kg_cumule >= seuil_or OU total_montant_cumule >= seuil_montant_or:
    niveau = 'or'
Sinon si total_kg_cumule >= seuil_argent OU total_montant_cumule >= seuil_montant_argent:
    niveau = 'argent'
Sinon:
    niveau = 'bronze'
```

### 8.3 Génération des numéros internes de colis

Format : `AC-AAAA-NNNN`
- AC = Africa Cargo
- AAAA = année courante
- NNNN = compteur incrémental remis à zéro chaque année

Exemple : `AC-2026-0001`, `AC-2026-0002`...

### 8.4 Notifications automatiques

À chaque mise à jour de statut, envoyer :
- WhatsApp si numéro vérifié (Phase 2)
- Email si activé dans les préférences
- Notification PWA si autorisée
- Toujours mettre à jour le statut dans l'app immédiatement

### 8.5 Workflow de livraison à domicile

```
1. Client clique "Demander livraison à domicile" (uniquement si statut 6)
2. Saisit son adresse à Cotonou + frais de livraison affichés
3. Validation côté admin
4. Statut passe à "Livraison programmée"
5. Mise à jour vers "Livré" après remise effective
```

---

## 9. Sécurité et conformité

### 9.1 Authentification
- Mots de passe hashés via bcrypt (Supabase natif)
- Session JWT avec refresh tokens
- Protection brute-force : 5 tentatives → blocage 15 min
- Reset password par email avec lien temporaire (1h)

### 9.2 Protection des données
- HTTPS obligatoire (redirect 80 → 443)
- Cookies HTTPOnly + Secure + SameSite=Lax
- CSP (Content Security Policy) strict
- Pas de stockage de données sensibles côté client

### 9.3 Row Level Security (Supabase)
- Activée sur TOUTES les tables
- Un client ne voit que ses propres données
- Un admin voit tout
- Logs d'accès actifs

### 9.4 Anti-piratage (le souci principal d'Africa Cargo)
- Cloudflare en proxy : protection DDoS et WAF
- Rate limiting sur les endpoints critiques
- Captcha sur l'inscription et le reset password
- Logs détaillés de chaque action admin

### 9.5 Sauvegardes
- Sauvegardes automatiques quotidiennes (Supabase)
- Rétention : 7 jours sur le plan gratuit, 30 jours sur le payant
- Export manuel possible à tout moment (admin)

### 9.6 RGPD-compliant (anticipation)
- Consentement explicite à l'inscription
- Possibilité de demander la suppression de compte
- Export des données personnelles sur demande

---

## 10. Plan de release

### Sprint 1 — Fondations (Semaine 1)
- Setup du projet React + Vite + Tailwind
- Configuration Supabase (projet, BDD, RLS)
- Création des tables et migrations
- Système d'authentification fonctionnel
- Layout de base (Header, Sidebar, Footer)
- Routes protégées

**Livrable** : un utilisateur peut s'inscrire et se connecter.

### Sprint 2 — Core client (Semaines 2-3)
- Tableau de bord client
- Enregistrement de colis (wizard 3 étapes)
- Upload de photos
- Liste des colis avec onglets
- Détail d'un colis avec timeline
- Suivi sans compte (par numéro)

**Livrable** : un client peut gérer ses colis. PREMIER VERSEMENT DÉBLOQUÉ.

### Sprint 3 — Backoffice (Semaine 4)
- Liste des colis admin (vue tableau dense)
- Mise à jour rapide des statuts
- Tableau de bord admin avec KPIs
- Configuration tarifs et adresses entrepôts
- Logs d'actions

**Livrable** : l'équipe Africa Cargo peut gérer les statuts.

### Sprint 4 — Fonctionnalités avancées (Semaine 5)
- Système de fidélité (Bronze, Argent, Or)
- Groupage de colis
- Livraison à domicile
- Avis clients
- Messagerie intégrée
- Configuration fidélité côté admin

**Livrable** : toutes les fonctionnalités V1 sont en place.

### Sprint 5 — Landing et polish (Semaine 6)
- Landing page complète
- Simulateur de prix public
- Adresses entrepôts publiques
- Statistiques publiques
- FAQ
- SEO et meta tags
- PWA (manifest, service worker, installation)

**Livrable** : le site est prêt pour le grand public.

### Sprint 6 — Tests et lancement (Semaine 7)
- Tests utilisateurs réels (Africa Cargo + amis)
- Corrections de bugs
- Optimisations performance
- Configuration nom de domaine
- Mise en production sur Vercel
- Configuration Cloudflare
- Formation de l'équipe Africa Cargo (1 session)
- Documentation utilisateur

**Livrable** : production live sur africacargo.bj. SECOND VERSEMENT DÉBLOQUÉ.

---

## Annexe : Définition de "Done" par fonctionnalité

Une fonctionnalité est considérée "Done" quand :
- [ ] Le code est versionné dans GitHub avec des commits clairs
- [ ] La fonctionnalité passe les tests manuels (critères d'acceptation validés)
- [ ] Le design est cohérent avec le reste de l'app (Tailwind + shadcn/ui)
- [ ] La fonctionnalité fonctionne sur mobile (testée sur Android et iPhone)
- [ ] Les erreurs sont gérées (loading states, error boundaries, messages utilisateur)
- [ ] Les données sont sécurisées par RLS Supabase
- [ ] Aucun warning console en production
- [ ] La fonctionnalité est documentée dans le README

---

**Fin du PRD — Africa Cargo Platform V1.0**
